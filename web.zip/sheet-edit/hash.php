<?php
$password = 'azzam123';
$hash = password_hash($password, PASSWORD_BCRYPT);
echo $hash; 
?>