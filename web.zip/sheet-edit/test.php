<?php
echo "Landing test OK";
exit;
?>
